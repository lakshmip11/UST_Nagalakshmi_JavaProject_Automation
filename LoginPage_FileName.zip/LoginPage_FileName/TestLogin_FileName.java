package seleniumWebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import utilsPackage.CaptureScreenShot;
import utilsPackage.FileNameMaker;
import utilsPackage.OpenChromeBrowser;

public class TestLogin_FileName {

	static WebDriver driver;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
        OpenChromeBrowser ob = new OpenChromeBrowser();
		
		driver = ob.openChrome();
		
		driver.get("https://the-internet.herokuapp.com/login");
		
		String u = "tomsmith";
		String p= "SuperSecretPasswor";
		driver.findElement(By.id("username")).sendKeys(u);
		driver.findElement(By.id("password")).sendKeys(p);
		
		driver.findElement(By.cssSelector("#login > button")).click();
	
	
	try {
		
		driver.findElement(By.partialLinkText("Logout"));
	}
	catch(NoSuchElementException e)
	{
		System.out.println("Login Failed");
		FileNameMaker fn = new FileNameMaker();
		
		String filename = fn.fileNameForLoging(u,p);
		System.out.println(filename);
		
		CaptureScreenShot cs = new CaptureScreenShot();
		cs.takeSnapShot(driver, filename);
	}
}
	
}

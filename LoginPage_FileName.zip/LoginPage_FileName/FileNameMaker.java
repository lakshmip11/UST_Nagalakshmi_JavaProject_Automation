package utilsPackage;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class FileNameMaker {
	
	public String fileNameForLoging(String u,String p) 
	{
		String filename;
		
		LocalDateTime now = LocalDateTime.now();
		System.out.println("Before Formatting: " + now );
		
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH-mm");
		filename = "C:\\Users\\Administrator\\Desktop\\Automation\\" + u + "_" + p + "_" + now.format(format) + ".jpg";

		
		return (filename);
	}

}
 
package utils;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGListener;
import org.testng.ITestResult;

public class TrackTestExecution implements ITestListener {


    public void onTestStart(ITestResult result) { 
        System.out.println("onTestStart>> ");
       }

   
    public void onTestSuccess(ITestResult result) {
        System.out.println("From Listener onTestSuccess>> PASSED");
       }

    public void onTestFailure(ITestResult result) { 
    	
        System.out.println("From Listener - Failed");
        //you can take a screenshot here
       }

   
    public void onTestSkipped(ITestResult result) { 
        System.out.println("onTestSkipped>> ");
       }

    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        System.out.println("onTestFailedButWithinSuccessPercentage>> ");
       }

    public void onStart(ITestContext context) {
        System.out.println("onStart>> ");
       }

    public void onFinish(ITestContext context) { 
        System.out.println("onFinish>> ");
	
    }


	public Class<? extends ITestNGListener>[] getValue() {
		// TODO Auto-generated method stub
		return null;
	}


	public void setValue(Class<? extends ITestNGListener>[] value) {
		// TODO Auto-generated method stub
		
	}

	
	
}

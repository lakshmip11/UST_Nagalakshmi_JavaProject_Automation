package TestCases;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import JobSearchAgent.JobSearch;
import JobSearchAgent.LoginPage;
import utils.OpenChromeBrowser;
import utils.ReadPropertiesFile;

public class JobSearch_TestCase {
	
	static WebDriver driver;
	static ReadPropertiesFile rpf;
	static LoginPage lp;
	static JobSearch js;
	
	@AfterClass
	public void closeDriver()
	{
		//Quit driver
		driver.quit();
	}
	
	@BeforeClass
	public void initDriver() throws IOException
	 {
		//Initializing Driver and Launch URL
		
		OpenChromeBrowser ob = new OpenChromeBrowser();
		driver = ob.openChrome();
		rpf = new ReadPropertiesFile();
		String val = rpf.readpropertyfile("baseurl");
		driver.get(val);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		lp=new LoginPage(driver);
		js=new JobSearch(driver);
	 }
	
  @Test
  public void doLogin() {
	  
	  //Enter valid email id and password for login to the job portal
	  lp.fillEmail("xyz@gmail.com");
	  lp.fillPassword("abcdefgh");
	  lp.clickSignInBtn();
	  System.out.println("Login success");
	  Assert.assertEquals(true, lp.isLoginSuccess());
  }
  
  @Test
  public void searchJob() throws Exception {
	  
	  //Search for valid job position
	  js.jobSearch("Java developer");
	  js.clickLink();
	  Assert.assertEquals(true, js.searchResults());
	  
  }
}

package JobSearchAgent;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	static WebDriver driver;
	boolean res;
	
	//Constructor
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	//Element references
	By email = By.id("username");
	By password = By.id("password");
	By signin = By.xpath("//button[contains(text(),\"Sign in\")]");
	By welcomemsg = By.xpath("//*[@class=\"t-16 t-black t-bold\"]");
	
	//Methods
	
	public void fillEmail(String s)
	{
		//Enter valid email id
		driver.findElement(email).sendKeys(s);
	}
	
	public void fillPassword(String p)
	{
		//Enter valid password
		driver.findElement(password).sendKeys(p);
	}
	
	public void clickSignInBtn()
	{
		//Click Signin button
		driver.findElement(signin).click();
	}
	public boolean isLoginSuccess()
	{
		//Check login success
		try {
			driver.findElement(welcomemsg);
			res = true;
		}
		catch(NoSuchElementException e)
		{
			res = false;
		}
		return res;		
		
	}
	
	
	
	
}

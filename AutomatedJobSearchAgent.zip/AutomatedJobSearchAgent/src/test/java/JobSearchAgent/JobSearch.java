package JobSearchAgent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

public class JobSearch {
	
	static WebDriver driver;
	boolean res;
	
	//Constructor
	public JobSearch(WebDriver driver)
	{
		this.driver=driver;
	}

	//Element references
	By searchbox = By.xpath("//input[@class=\"search-global-typeahead__input\"]");
	By joblnk = By.xpath("/html/body/div[5]/div[3]/div[2]/div/div[1]/main/div/div/div[1]/div/ul[2]/li[1]/div/div/div/div[2]/div[1]/div[1]/div/span/span");
	By jobname = By.xpath("//*[@id=\"results-list__title\"]");
	By srchres = By.xpath("//*[@id=\"main\"]/div/div[2]/div[1]/header/div[1]/small/div/span");
	
	
    //Methods
	public void jobSearch(String j) throws Exception
	{
		//Enter valid job keyword
		driver.findElement(searchbox).sendKeys(j + Keys.ENTER);
		Thread.sleep(1000);
		
	}
	
	public void clickLink()
	{
		//Click the job link
		driver.findElement(joblnk).click();
		
	}
	
		
	public boolean searchResults()
	{
		try {
	    	//Bring search results
	    	String jobnme = driver.findElement(jobname).getText();
	    	String srchresult = driver.findElement(srchres).getText();
		    System.out.println(jobnme + " " + srchresult);
		    res = true;
	    }		
	
	    catch(NoSuchElementException e)
	    {
	     System.out.println("no results found " );
	     res = false;
	    }
		return res;
	}
}

package fileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileRead_Assignment {

	static File myFile;
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		try {
			
		myFile = new File("C://Users//Administrator//Desktop//Automation//File1.txt");
		
		System.out.println(myFile.exists());
		
		Scanner myScanner = new Scanner(myFile);
		
		while(myScanner.hasNextLine())
		{
			String line = myScanner.nextLine();
			
			System.out.println(line);
			
			String[] userdetails = line.split(",");
			
			for(int i = 0; i < userdetails.length; i++)
			{
				switch(i)
				{
	 	
				case 0:
				{
				System.out.println("Username: " + userdetails[i]);
				break;
				}
				case 1:
				{
				System.out.println("Password: " + userdetails[i]);
				break;
				}
				
				}
				
			}
		}
				
		}
		catch(FileNotFoundException f)
		{
		
			System.out.println("File not found");
		}
		
		finally {
			myFile = 
null;
		}
		}
		
		

}

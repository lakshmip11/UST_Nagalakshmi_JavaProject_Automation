package fileHandling;

import java.io.FileWriter;
import java.io.IOException;

public class CreateFile {

	public static void main(String[] args) throws IOException {
		 
		FileWriter myWriter = new FileWriter("C://Users//Administrator//Desktop//Automation//newfile.txt");
		
		myWriter.write("Hello" + "\n\r" );
		myWriter.append("Adding a new line");

		myWriter.flush();

	}

}

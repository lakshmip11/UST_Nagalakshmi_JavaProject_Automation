package TestCases;

import org.testng.annotations.Test;

public class DateFormatTest {
  @Test
  public void f() {
  }
}

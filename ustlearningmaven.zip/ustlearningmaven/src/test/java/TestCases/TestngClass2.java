package TestCases;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class TestngClass2 {
	@Test
	  public void d() {
		  System.out.println("method - d from Class2");
	  }
	  
	
	 @Test (groups = "Smoke Tests")
	  public void e() {
		  System.out.println("method - e from Class2");
	  }
	  
	  @Test
	  public void f() {
		  System.out.println("method - f from Class2");
	  }

}

package TestCases;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import utils.BrokenLinkChecker;
import utils.OpenChromeBrowser;
import utils.ReadPropertiesFile;

public class BrokenLinkAndImagesEBay_TestCase {

	static WebDriver driver;
    public static BrokenLinkChecker blc;
    static boolean result;
    static ReadPropertiesFile rpf;
    
 @BeforeClass
 public void initDriver() throws IOException
 {
	//Initializing Driver and Launch URL
	
	OpenChromeBrowser ob = new OpenChromeBrowser();
	driver = ob.openChrome();
	rpf = new ReadPropertiesFile();
	String val = rpf.readpropertyfile("baseurl");
	driver.get(val);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	
	 blc = new BrokenLinkChecker();
 }

 @AfterClass
 public void connClose()
 {
	 //Close the Driver
	 driver.close();
 }
 
  @Test
  public void brokenLinkAndImageCheckTestCase()
  { 
	  //Read the links or images
	  java.util.List <WebElement>  allImagesAndLinks = driver.findElements(By.xpath("//*[self::a or self::img]"));
	  
	  System.out.println("No. of Images and Links : " + allImagesAndLinks.size());
	  
	  String url;
	  int responsecode = 0;
	  for(WebElement l: allImagesAndLinks)
	  {
		  //Print the links and links text
		  String tagname = l.getTagName();
		  System.out.println(tagname);
		  if(tagname.equals("img"))
		  {
			  url = l.getAttribute("src");
			  tagname = "Image!";
			  try {
				responsecode = blc.verifyLink(url);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  else
		  {
			  url = l.getAttribute("href");
			  tagname = "Link!";
			  try {
				responsecode = blc.verifyLink(url);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  
		  result = (responsecode==200) ? true : false;
		  
		  Reporter.log("Tagname: " + tagname + "----" + url + " " + responsecode + "<br/>");
		  
		  Assert.assertEquals(true, result);
	  }
	  
  }
  
}

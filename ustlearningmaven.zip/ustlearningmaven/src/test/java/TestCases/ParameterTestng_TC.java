package TestCases;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParameterTestng_TC {
  
  boolean res;
  @Parameters({"first-name"})	
  @Test
  public void A(String fn) {
	  
	  System.out.println("First name: " + fn);
	  assert "Nagalakshmi".equals(fn);
	  
  }
  
  @Parameters({"second-name"})
  @Test
  public void B(String sn) {
	   System.out.println("Second name: " + sn);
	   assert "Padmanabham".equals(sn);
  }
}

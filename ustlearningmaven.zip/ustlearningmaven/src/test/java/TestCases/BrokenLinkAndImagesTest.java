package TestCases;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import utils.OpenChromeBrowser;

public class BrokenLinkAndImagesTest {
  
 static WebDriver driver;
 
 @BeforeClass
 public void initDriver(WebDriver driver)
   {
	 //Initializing Driver
	 
	 OpenChromeBrowser ob = new OpenChromeBrowser();
	 driver = ob.openChrome();
	 driver.get("https://the-internet.herokuapp.com/broken_images");
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
   }
 
 @AfterClass
 public void connClose()
   {
	 driver.close();
   }
 
 
  @Test
  public void brokenLinks() {
  }
 
 @Test
 public void brokenImages() {
 }
}

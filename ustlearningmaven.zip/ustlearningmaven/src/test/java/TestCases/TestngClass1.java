package TestCases;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;


public class TestngClass1 {
  
  @Test (groups = "Smoke Tests")
  public void a() {
	  System.out.println("method - a from Class1");
  }
  
  @Test
  public void b() {
	  System.out.println("method - b from Class1");
  }
  
  @Test (groups = "Smoke Tests")
  public void c() {
	  System.out.println("method - c from Class1");
  }

}



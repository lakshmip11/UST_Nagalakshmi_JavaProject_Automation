package seleniumWebDriver;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Alerts {
	
	static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {
		
        driver = new ChromeDriver();
		
		//Put an Implicit wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Launch the URL		
	    driver.get("C:\\Users\\Administrator\\Desktop\\Automation\\alerts.html");
	    
	    
	    //This will click "Show confirm box" button in the alerts html page
	    driver.findElement(By.id("btnConfirm")).click();
	    /*
	    Thread.sleep(500);
	    driver.switchTo().alert().accept();
	    String show_conf = driver.findElement(By.id("output")).getText();
	    System.out.println(show_conf);
		*/
		
	    /*
	    Thread.sleep(500);
	    driver.switchTo().alert().dismiss();
	    String show_rej = driver.findElement(By.id("output")).getText();
	    System.out.println(show_rej);
	    */
	   
	    /*
		//This will click "Show alert" button in the alerts html page
	    driver.findElement(By.id("btnAlert")).click();
	    Thread.sleep(500);
	    driver.switchTo().alert().accept();
	    //driver.switchTo().alert().dismiss();
	    String show_alrt = driver.findElement(By.id("output")).getText();
	    System.out.println(show_alrt);
	    */
	    
	    
	    /*		
	    //This will click "Show Prompt" button in the alerts html page
	    driver.findElement(By.id("btnPrompt")).click();
	    String show_prmpt = driver.switchTo().alert().getText();
	    System.out.println(show_prmpt);
	    //Thread.sleep(1000);
	    driver.switchTo().alert().sendKeys("Automation");
	    //Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    //driver.switchTo().alert().dismiss();
	    String text_prmpt = driver.findElement(By.id("output")).getText();
	    System.out.println(text_prmpt);
		*/
	    
	}

	

	
}

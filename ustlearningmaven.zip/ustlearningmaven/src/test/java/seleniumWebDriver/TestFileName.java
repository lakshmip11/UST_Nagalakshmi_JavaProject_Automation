package seleniumWebDriver;

import utils.FileNameMaker;

public class TestFileName {

	public static void main(String[] args) {
		
		FileNameMaker fn = new FileNameMaker();
		
		String currfilename = fn.fileNameForLoging("abc", "def");
		System.out.println(currfilename);
		

	}

}

package javaHandsOn;

public class Sbi extends Rbi implements NationalBank {

	
	
	
		public void calculateFD()
		{
			System.out.println("FD rate of interest is 8%");
		}
		
		
		
	
	

	

}

package javaHandsOn;

public class Circle extends Shape {
	
	void calculateArea() 
	{
		System.out.println("Area of Circle");
	}

}

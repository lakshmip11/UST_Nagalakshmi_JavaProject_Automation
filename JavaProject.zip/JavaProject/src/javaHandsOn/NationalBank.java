package javaHandsOn;

interface NationalBank {

	void calculateFD();
	
}

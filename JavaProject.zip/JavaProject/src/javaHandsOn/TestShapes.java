package javaHandsOn;

public class TestShapes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Circle circle1 = new Circle();
		circle1.calculateArea();
		
		Rectangle rectangle1 = new Rectangle();
		rectangle1.calculateArea();
	}

}

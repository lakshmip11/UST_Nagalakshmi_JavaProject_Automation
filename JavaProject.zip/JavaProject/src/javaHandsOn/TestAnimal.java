package javaHandsOn;

public class TestAnimal {

	public static void main(String[] args) {
		
		Cat smiley = new Cat();
		
		smiley.height = 10;
		smiley.colour = "Brown";
		
		smiley.makeSound();

	}

}

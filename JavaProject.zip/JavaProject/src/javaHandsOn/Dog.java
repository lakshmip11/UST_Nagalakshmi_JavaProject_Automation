package javaHandsOn;

public class Dog extends Animal{
	
	

}

package javaHandsOn;

public class Rectangle extends Shape{
	
	void calculateArea()
	{
		System.out.println("Area of Rectangle");
	}

}

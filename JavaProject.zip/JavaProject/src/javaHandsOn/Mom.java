package javaHandsOn;

public class Mom {

	static String eyeColour="Blue";
}

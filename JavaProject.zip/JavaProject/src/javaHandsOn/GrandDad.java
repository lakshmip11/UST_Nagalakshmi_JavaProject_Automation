package javaHandsOn;

public interface GrandDad {
	
	final int shoeSize = 10;


}

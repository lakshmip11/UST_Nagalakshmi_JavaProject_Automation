package javaHandsOn;

public class Cat extends Animal {
	
	
	public void makeSound()
	{
		System.out.println("Meow height is: " + height + " " + "and Colour is:" + colour);
	}
}

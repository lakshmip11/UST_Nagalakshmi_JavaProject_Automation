package javaHandsOn;

public class PlugPoint {
	

}

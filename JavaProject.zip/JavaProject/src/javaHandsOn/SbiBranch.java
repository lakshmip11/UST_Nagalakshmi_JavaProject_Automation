package javaHandsOn;

public class SbiBranch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Sbi sbihyd = new Sbi();
     
     sbihyd.calculateFD();
     
     float dr = sbihyd.readDollarRate();
     
    System.out.println(dr);
	}

}

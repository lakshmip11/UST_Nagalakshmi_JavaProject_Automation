package javaHandsOn;

public class Rbi {

	static final float dollarRate = 72;


public float readDollarRate()
{
	return dollarRate;
}

}
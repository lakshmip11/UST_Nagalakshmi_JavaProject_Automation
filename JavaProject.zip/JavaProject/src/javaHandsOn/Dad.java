package javaHandsOn;

interface Dad {
	
 public static final int height = 156;
 
}

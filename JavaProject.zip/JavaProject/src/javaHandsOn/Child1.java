package javaHandsOn;

public class Child1 extends Mom implements Dad,GrandDad{
	
	public static void main(String [] args) {
		
		System.out.println("Child's height is " + (Dad.height + 10) + " ; " + "Eyecolour inherited from mom is " + eyeColour);
		
		System.out.println("Large feet from grandDad " + (GrandDad.shoeSize - 1));
	}

}

package javaHandsOn;

public class ExceptionalHandling {

	public static void main(String[] args) {
		
		int i = 10;
		int j = 0;
	
		try {
		int result = i/j;
		
		System.out.println("Result is: " + result);
		}
		catch(ArithmeticException ex )
		{
		  System.out.println(ex.getMessage());
		}
		
		finally {
			System.out.println("Finally executing");
		}
		
	}
		

}

package javaHandsOn;

public class Animal {

	    int height;
	    String colour;
	    
		public void makeSound()
		{
			
		}
		
	

}

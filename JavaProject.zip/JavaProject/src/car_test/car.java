package car_test;

public class car {
	
	public String Colour;
	public int Height;
	
	public boolean start()
	{
		System.out.println("Started from Car Class");
		return true;
	}
	
	public boolean stop()
	{
		System.out.println("Stopped");
		return true;
	}
	
	public String getColour()
	{
		return this.Colour;
	}
	
	public void setColour(String c)
	{
		this.Colour = c;
	}

}

package car_test;

public class electricCar extends car{
	
	public boolean autoSteer()
	{
		System.out.println("AutoSteer is ready");
		return true;
	}

	public boolean start()
	{
		System.out.println("Started by pushing a button");
		return true;
	}
}

package car_test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class testHonda {

	public static electricCar honda;
	public boolean result;
	
	@BeforeClass
	public static void doFirst() {
		
		honda =  new electricCar();
		
		//honda.Colour = "Red";
		//honda.Height = 100;
		
		System.out.println("Executing first");
		
	}
	
	@Test
	public void testStart()
	{
		boolean started = honda.start();
		Assert.assertEquals(true, started);
	}
	
	
	@Test
	public void testColourOfHonda() 
	{
		
		honda.setColour("Blue");
		System.out.println(honda.getColour());
		
		//ternary operator-short hand for if else condition
		result = (honda.getColour()=="Blue") ? (result=true):(result=false);
		
		Assert.assertEquals(true, result);
				
	}
	
	@Test
	public void testElectricCarStart()
	{
		result = (honda.autoSteer()==true) ? (result=true):(result=false);
		
		Assert.assertEquals(true, result);
	}

}

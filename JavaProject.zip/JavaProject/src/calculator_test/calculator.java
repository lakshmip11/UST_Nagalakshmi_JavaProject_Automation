package calculator_test;

public class calculator {
	
	//https://github.com/balamurthy68/USTJavaSelenium
	
	public static int add(int n1,int n2) 
	{
		
		return n1+n2;
		
	}

	public static int add(int n1,int n2,int n3)
	{
		
		return n1+n2+n3;
		
	}
	
	public static long add(double d1,int d2, int d3)
	{
		return (long) (d1+d2+d3);
	}
}

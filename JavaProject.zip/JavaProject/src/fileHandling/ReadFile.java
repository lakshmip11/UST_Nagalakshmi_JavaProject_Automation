package fileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;



public class ReadFile {

	static File myFile;
	
	public static void main(String[] args) throws FileNotFoundException {

		try {
	     myFile = new File("C://Users//Administrator//Desktop//Automation//UST.txt");

		 System.out.println(myFile.exists());
		 
		 Scanner myScanner = new Scanner(myFile);
		 
		 while (myScanner.hasNextLine())
			 
		 {
			 String line = myScanner.nextLine();
			 
			 System.out.println(line);
		 }
		 
		}
		catch (FileNotFoundException f)
		{
			System.out.println("File is not found");
		}
		finally {
			myFile = null;
		}

	
	}



}

package fileHandling;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;

public class ReadPropertiesFileExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

	  Properties p = new Properties();
	  
	  FileInputStream fis = new FileInputStream("C://Users//Administrator//eclipse-workspace//JavaProject//config.properties");
	  p.load(fis);
	  
	  /*String myURL = p.getProperty("url");
	  System.out.println(myURL);*/
	  
	  for (Entry<Object,Object> e :p.entrySet())
	  {
		  System.out.println(e);
	  }
	  	  
	}

}

package fileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileRead_AssgExample {

	public static void main(String[] args) throws FileNotFoundException {
		
		File myFile1 = new File("C://Users//Administrator//Desktop//Automation//File2.txt");
		
		System.out.println(myFile1.exists());
		
		Scanner myScanner1 = new Scanner(myFile1);
		
		while(myScanner1.hasNextLine())
		{
			String line1 = myScanner1.nextLine();
			System.out.println(line1);
			
			String[] udetails = line1.split(" ");
		}

	}

}

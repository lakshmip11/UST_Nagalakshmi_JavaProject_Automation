package strings;

public class StringConcate {

	public static void main(String[] args) {

		String s1 ="abcd,efgh";
		String s2 = new String("abcd");
		
		System.out.println(s1+s2);

		System.out.println(s1.length());
		
		String[] str1Array = s1.split(",");
		
		for(int i = 0; i < str1Array.length; i++)
		{	
			System.out.println(str1Array[i]);
		}
			
				

	}


}

package strings;

public class StringBuilderExample {

	public static void main(String[] args) {
		
		//StringBuilder example. StringBuilder is Mutable. Strings are immutable;
		
		StringBuilder str = new StringBuilder("Welcome to UST");
		
		System.out.println(str);
		
		str.append(" Global");
		System.out.println(str);

		str.insert(8, "Hyderabad");
		System.out.println(str);
		
		str.delete(17, 19);
		System.out.println(str);
		
		str.replace(8, 17, "HYD");
		System.out.println(str);
		
		System.out.println(str.substring(12, 15));
		
		System.out.println(str.reverse());
		
	}

}

package dateAndTime;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class LocalDateTimeExample {

	public static void main(String[] args) {
		
		LocalDateTime now = LocalDateTime.now();
		
		System.out.println("Before formatting: " + now);
		
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:MM:ss");
		
		String formatDateTime = now.format(format);
		System.out.println("After formatting: " + formatDateTime);
		
		
		
		int curtime = LocalTime.now().getHour();
		String greet;
		
		
		if (curtime < 12)
		{	
			greet = "Good morning";
		}
		else if (curtime >= 12 && curtime <= 16)
		{
			greet = "Good afternoon";
		}
		else if (curtime >= 16 && curtime <= 19)
		{
			greet = "Good evening";
		}
		else 
		{
			greet = "Good night";
		}

		System.out.println(LocalTime.now().getHour() + " " + greet);
	}

}

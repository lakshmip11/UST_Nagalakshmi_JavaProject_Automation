package utilsPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class OpenChromeBrowser {

		WebDriver driver;
		
		public WebDriver openChrome(){
			
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\eclipse-workspace\\ustlearningmaven\\chromedriver-win64\\chromedriver.exe");
		
			ChromeOptions options = new ChromeOptions();
			options.setBrowserVersion("123");
		    driver = new ChromeDriver(options);
		    
		    return driver;
		    
		}
		
		
	}


package smokeTests;

import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import junit.framework.Assert;
import utils.OpenChromeBrowser;

public class HomePageCheckTitleAndFooter_TestCase {
 
	static OpenChromeBrowser ob = OpenChromeBrowser.getInstance();
	
	
	static WebDriver driver;
	
	
	@BeforeClass
	public static void LaunchUrl()
	{
		//To open browser
		//OpenChromeBrowser ob = new OpenChromeBrowser();
		//driver = ob.openChrome();
		driver = ob.openChrome();
		//Launch the URL - redbus.com
		driver.get("https://www.redbus.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
  @Test
  public void checkTitle() 
  {
	  String expected_Title = "Book Bus Tickets Online with redBus!";
		 System.out.println("Expected Title is: " + expected_Title);
		 String actual_Title = driver.getTitle();
		 System.out.println("Actual Title is: " + actual_Title);
		 
		 Assert.assertEquals(actual_Title, expected_Title);
  }
}

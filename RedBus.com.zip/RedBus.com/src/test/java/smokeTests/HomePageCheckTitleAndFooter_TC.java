	package smokeTests;



import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;

import junit.framework.Assert;
import utils.OpenChromeBrowser;

	
public class HomePageCheckTitleAndFooter_TC {

	private OpenChromeBrowser ob = OpenChromeBrowser.getInstance();
	private static WebDriver driver;
	
	
	@BeforeClass
	public static void LaunchUrl()
	{
		//To open browser
		//OpenChromeBrowser ob = new OpenChromeBrowser();
		//driver = ob.openChrome();
		
		//Launch the URL - redbus.com
		driver.get("https://www.redbus.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Test
    public void CheckTitle() 
	{
	 String expected_Title = "Book Bus Tickets Online with redBus!";
	 System.out.println("Expected Title is: " + expected_Title);
	 String actual_Title = driver.getTitle();
	 System.out.println("Actual Title is: " + actual_Title);
	 
	 Assert.assertEquals(actual_Title, expected_Title);
	 
	}
	
	@Test
	public void CheckFooter()
	{
	 //Scroll down to make the footer text visible
	 JavascriptExecutor js = (JavascriptExecutor) driver;
	 
	 //Scroll down till the bottom of the page
	 js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	 String expected_Footer = "2024 ibibogroup All rights reserved";
	 String actual_Footer = driver.findElement(By.xpath("//*[@class=\"rdc-ibibo\"]//child::span")).getText();
	 System.out.println("Actual Footer: " + actual_Footer);
		        
	 Assert.assertEquals(actual_Footer, expected_Footer);
		        
		
	}
}

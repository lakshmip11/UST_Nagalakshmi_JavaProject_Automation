package testNG_Examples;

import org.testng.annotations.Test;

public class Testng2_TC {
  @Test 
  public void c() {
	  System.out.println("c method from Testng class2");
  }
  
  @Test
  public void d() {
	  System.out.println("d method from Testng class2");
  }
}

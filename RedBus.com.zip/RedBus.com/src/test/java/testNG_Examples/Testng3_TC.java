package testNG_Examples;

import org.testng.annotations.Test;

public class Testng3_TC {
	
	@Test (priority=2)
	  public void e() {
		  System.out.println("e method from Testng class2");
	  }
	  
	  @Test (priority=1)
	  public void f() {
		  System.out.println("f method from Testng class2");
	  }
}

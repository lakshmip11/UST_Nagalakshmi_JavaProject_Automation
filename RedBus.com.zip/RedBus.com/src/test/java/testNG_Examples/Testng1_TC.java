package testNG_Examples;

import org.testng.annotations.Test;

public class Testng1_TC {
	
  @Test (dependsOnMethods="b")
  public void a() 
  {
	  System.out.println("a method from testng class1");
  }
  
  @Test
  public void b()
  {
	  System.out.println("b method from testng class1");
  }
}

package sanityTests;

//import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import junit.framework.Assert;
import utils.OpenChromeBrowser;

public class HeaderAndLogo_TC{

	static WebDriver driver1;
	
	@BeforeClass
	public static void OpenBroswer()
	{
		//To open browser
		//OpenChromeBrowser ob = new OpenChromeBrowser();
		//driver1 = ob.openChrome();
		
		//Launch the URL - redbus.com
		driver1.get("https://www.redbus.com/");
		driver1.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Test

	public void CheckHeader() 
	{
		
		String expected_Header = "Book your journey now with the world's largest bus platform";
		String actual_Header = driver1.findElement(By.xpath("//h1[contains(text(), \"Book your journey\")]")).getText();
		System.out.println("Actual Header: " + actual_Header);
		
		Assert.assertEquals(actual_Header, expected_Header);

	}
	
	@Test
	public void CheckLogo()
	{
		
	}

}

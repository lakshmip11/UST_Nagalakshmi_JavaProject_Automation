package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class OpenChromeBrowser {

	private static OpenChromeBrowser instance = null;
	private WebDriver driver;
	
	private OpenChromeBrowser()
	{
		this.driver=driver;
	}
	
	public WebDriver openChrome()
	{		
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\eclipse-workspace\\RedBus.com\\chromedriver-win64\\chromedriver.exe");
	ChromeOptions options = new ChromeOptions();
	options.setBrowserVersion("123");
    driver = new ChromeDriver(options);
    
    return driver; 
	}
	
	public static OpenChromeBrowser getInstance()
	{
		if (instance == null)
		{
			instance = new OpenChromeBrowser();
		}
		return instance;
	}	
}
